import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a blue toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      home: Home(),
      routes: {
        '/original' : (context)=>Original(),
        '/rose' : (context)=>Rose(),
        '/mara' : (context)=>Mara(),
        '/mararose' : (context)=>MaraRose(),
        '/foot' : (context)=>Foot(),
        '/tang' : (context)=>Tang(),
        '/half' : (context)=>Half(),
        '/oksae' : (context)=>Oksae(),
        '/nyokki' : (context)=>Nyokki(),
        '/doublepp' : (context)=>Doublepp(),
        '/bacon' : (context)=>Bacon(),
        '/sweet' : (context)=>Sweet(),
        '/woojo' : (context)=>Woojo(),
        '/shoot' : (context)=>Shoot(),
        '/bong' : (context)=>Bong(),
        '/macarong' : (context)=>Macarong(),
        '/soop' : (context)=>Soop(),
        '/bb' : (context)=>Bb(),
      },
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => HomePageState();
}
class HomePageState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('팡팡이츠!',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            scrollDirection: Axis.vertical,
            children: [
              ListTile(
                leading: Image.asset('assets/배라.jpg',width: 100,),
                title: Text('배스킨라빈스'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return Fourth();
                      },),
                  );
                },
              ),
              ListTile(
                leading: Image.asset('assets/엽떡.jpg',width: 100,),
                title: Text('동대문 엽기떡볶이'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return SecondPage();
                      },),
                  );
                },
              ),
              ListTile(
                leading: Image.asset('assets/nmplogo.png',width: 100,),
                title: Text('노모어피자'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return Third();
                      },),
                  );
                },
              ),
              ListTile(
                leading: Image.asset('assets/60logo.jpg',width: 100,),
                title: Text('60계치킨'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return Fifth();
                      },),
                  );
                },
              ),
              ListTile(
                leading: Image.asset('assets/twologo.jpg',width: 100,),
                title: Text('투썸플레이스'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return Sixth();
                      },),
                  );
                },
              ),
              ListTile(
                leading: Image.asset('assets/mclogo.png',width: 100,),
                title: Text('맥도날드'),
                subtitle: Text('분당서현점'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context){
                        return Seventh();
                      },),
                  );
                },
              ),
            ],
          )
      ),
    );
  }
}


//엽떡

class SecondPage extends StatefulWidget {
  const SecondPage({super.key});

  @override
  State<SecondPage> createState() => _SecondPageState();
}

var or_isChecked = false;
var ro_isChecked = false;
var ma_isChecked = false;
var mr_isChecked = false;
var fo_isChecked = false;
var tg_isChecked = false;

class _SecondPageState extends State<SecondPage> {
  List<String> cartList= [];
  List<String> selectedItems = [];

  void initState(){
    super.initState();
    print('FirstPage initState');
  }

  void dispose(){
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('동대문 엽기떡볶이',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/original');
                  },
                  child: Image.asset('assets/yddeok/오리지널.png',height: 200,),
                ),
                Text('엽기메뉴', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: or_isChecked,
                  onChanged: (value) {
                    setState(() {
                      or_isChecked = value!;
                      updateSelectedItems('엽기메뉴', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/rose');
                  },
                  child: Image.asset('assets/yddeok/로제.png',height: 200,),
                ),
                Text('로제메뉴', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: ro_isChecked,
                  onChanged: (value) {
                    setState(() {
                      ro_isChecked = value!;
                      updateSelectedItems('로제메뉴', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/mara');
                  },
                  child: Image.asset('assets/yddeok/마라.png',height: 200,),
                ),
                Text('마라떡볶이', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: ma_isChecked,
                  onChanged: (value) {
                    setState(() {
                      ma_isChecked = value!;
                      updateSelectedItems('마라떡볶이', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/mararose');
                  },
                  child: Image.asset('assets/yddeok/마라로제.png',height: 200,),
                ),
                Text('마라로제떡볶이', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: mr_isChecked,
                  onChanged: (value) {
                    setState(() {
                      mr_isChecked = value!;
                      updateSelectedItems('마라로제떡볶이', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/foot');
                  },
                  child: Image.asset('assets/yddeok/엽기무뼈닭발.png',height: 200,),
                ),
                Text('엽기 무뼈닭발', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: fo_isChecked,
                  onChanged: (value) {
                    setState(() {
                      fo_isChecked = value!;
                      updateSelectedItems('엽기 무뼈닭발', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/tang');
                  },
                  child: Image.asset('assets/yddeok/엽기닭볶음탕.png',height: 200,),
                ),
                Text('엽기닭볶음탕', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: tg_isChecked,
                  onChanged: (value) {
                    setState(() {
                      tg_isChecked = value!;
                      updateSelectedItems('엽기닭볶음탕', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(8.0),
        child: IconButton(icon: Icon(Icons.add_shopping_cart,size: 50,),onPressed: () {
          // Add selected items to cartList
          cartList.addAll(selectedItems);

          // Show a message or perform other actions
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('장바구니에 추가되었습니다!!: $selectedItems', style: TextStyle(fontSize: 16),),),
          );
        },),
      ),
    );
  }
  void updateSelectedItems(String item, bool isChecked) {
    setState(() {
      if (isChecked) {
        selectedItems.add(item);
      } else {
        selectedItems.remove(item);
      }
    });
  }
}


class Original extends StatelessWidget {
  const Original({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('엽기메뉴',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/오리지널.png', height: 300,),
            Text('엽기메뉴  14,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('떡볶이/오뎅/반반 中 선택',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            Text('(떡볶이 → 분모자 변경 시 + 3,000원)'),
            SizedBox(height: 40,),
            Image.asset('assets/yddeok/original/taste_original.png',width: 450,),
            SizedBox(height: 40,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/주먹김밥.png',width: 130,),
                    Text('주먹김밥(셀프)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/바삭치즈만두.png', width: 130,),
                    Text('바삭치즈만두(7개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/엽도그.png', width: 130,),
                    Text('엽도그',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/콘마요.png', width: 130,),
                    Text('콘마요',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,500원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Rose extends StatelessWidget {
  const Rose({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('로제메뉴',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/로제.png', height: 300,),
            Text('로제메뉴  16,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('떡볶이/오뎅/반반 中 선택',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            Text('(떡볶이 → 분모자 변경 시 + 3,000원)'),
            SizedBox(height: 40,),
            Image.asset('assets/yddeok/rose/taste_rose.png',width: 450,),
            SizedBox(height: 40,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/rose/엽기오돌뼈밥.png',width: 130,),
                    Text('엽기오돌뼈밥',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('4,500원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/rose/중국당면.png', width: 130,),
                    Text('중국당면',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,500원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/rose/베이컨.png', width: 130,),
                    Text('베이컨',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('3,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/rose/치즈만두.png', width: 130,),
                    Text('퐁당치즈만두(7개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Mara extends StatelessWidget {
  const Mara({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('마라떡볶이',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/마라.png', height: 300,),
            Text('마라떡볶이  16,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('떡볶이 메뉴만 선택 가능(오뎅/반반/분모자 불가)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            Text('세트메뉴 적용 불가'),
            SizedBox(height: 40,),
            Image.asset('assets/yddeok/mara/taste_mara.png',width: 450,),
            SizedBox(height: 40,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/참치마요밥.png',width: 130,),
                    Text('참치마요밥',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('3,500원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/꿔바로우.png', width: 130,),
                    Text('꿔바로우(5개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('5,900원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/오뎅튀김.png', width: 130,),
                    Text('오뎅튀김(15개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/우동사리.png', width: 130,),
                    Text('우동사리',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class MaraRose extends StatelessWidget {
  const MaraRose({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('마라로제떡볶이',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/마라로제.png', height: 300,),
            Text('마라로제떡볶이  18,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('떡볶이 메뉴만 선택 가능(오뎅/반반/분모자 불가)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
            Text('세트메뉴 적용 불가'),
            SizedBox(height: 40,),
            Image.asset('assets/yddeok/rose/taste_rose.png',width: 450,),
            SizedBox(height: 40,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/주먹김밥.png',width: 130,),
                    Text('주먹김밥(셀프)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/꿔바로우.png', width: 130,),
                    Text('꿔바로우(5개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('5,900원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/바삭치즈만두.png', width: 130,),
                    Text('바삭치즈만두(7개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mararose/순대.png', width: 130,),
                    Text('순대',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('3,000원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Foot extends StatelessWidget {
  const Foot({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('엽기무뼈닭발',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/엽기무뼈닭발.png', height: 300,),
            Text('엽기무뼈닭발  16,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 50,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/original/주먹김밥.png',width: 130,),
                    Text('주먹김밥(셀프)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/foot/계란야채죽.png', width: 130,),
                    Text('계란야채죽',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('5,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/foot/계란찜.png', width: 130,),
                    Text('계란찜',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Tang extends StatelessWidget {
  const Tang({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('엽기닭볶음탕',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/yddeok/엽기닭볶음탕.png', height: 300,),
            Text('엽기닭볶음탕  24,000원',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Image.asset('assets/yddeok/original/taste_original.png',width: 450,),
            SizedBox(height: 50,),
            Text('추천 사이드&토핑',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/yddeok/tang/공깃밥.png',width: 130,),
                    Text('공깃밥',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('1,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/tang/오징어튀김.png', width: 130,),
                    Text('오징어튀김(1개)',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('1,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/tang/떡추가.png', width: 130,),
                    Text('떡추가',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('1,000원'),
                  ],
                ),
                Column(
                  children: [
                    Image.asset('assets/yddeok/mara/우동사리.png', width: 130,),
                    Text('우동사리',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                    Text('2,000원'),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


//노모어피자

class Third extends StatefulWidget {
  const Third({super.key});

  @override
  State<Third> createState() => _ThirdState();
}
var hf_isChecked = false;
var os_isChecked = false;
var bm_isChecked = false;
var dp_isChecked = false;
var bp_isChecked = false;
var sp_isChecked = false;

class _ThirdState extends State<Third> {
  List<String> cartList= [];
  List<String> selectedItems = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('노모어피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/half');
                  },
                  child: Image.asset('assets/nomore/하프앤하프.png',height: 200,),
                ),
                Text('하프 앤 하프 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: hf_isChecked,
                  onChanged: (value) {
                    setState(() {
                      hf_isChecked = value!;
                      updateSelectedItems('하프 앤 하프 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/oksae');
                  },
                  child: Image.asset('assets/nomore/옥새.png',height: 200,),
                ),
                Text('옥수수 새우 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: os_isChecked,
                  onChanged: (value) {
                    setState(() {
                      os_isChecked = value!;
                      updateSelectedItems('옥수수 새우 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/nyokki');
                  },
                  child: Image.asset('assets/nomore/뇨끼.png',height: 200,),
                ),
                Text('바질 마스카포네 뇨끼 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: bm_isChecked,
                  onChanged: (value) {
                    setState(() {
                      bm_isChecked = value!;
                      updateSelectedItems('바질 마스카포네 뇨끼 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/doublepp');
                  },
                  child: Image.asset('assets/nomore/더블페퍼로니.png',height: 200,),
                ),
                Text('더블 페퍼로니 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: dp_isChecked,
                  onChanged: (value) {
                    setState(() {
                      dp_isChecked = value!;
                      updateSelectedItems('더블 페퍼로니 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/bacon');
                  },
                  child: Image.asset('assets/nomore/베이컨.png',height: 200,),
                ),
                Text('베이컨 포테이토 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: bp_isChecked,
                  onChanged: (value) {
                    setState(() {
                      bp_isChecked = value!;
                      updateSelectedItems('베이컨 포테이토 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/sweet');
                  },
                  child: Image.asset('assets/nomore/고구마.png',height: 200,),
                ),
                Text('스윗 고구마 피자', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: sp_isChecked,
                  onChanged: (value) {
                    setState(() {
                      sp_isChecked = value!;
                      updateSelectedItems('스윗 고구마 피자', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(8.0),
        child: IconButton(icon: Icon(Icons.add_shopping_cart,size: 50,),onPressed: () {
          // Add selected items to cartList
          cartList.addAll(selectedItems);

          // Show a message or perform other actions
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('장바구니에 추가되었습니다!!: $selectedItems', style: TextStyle(fontSize: 16),),),
          );
        },),
      ),
    );
  }

  void updateSelectedItems(String item, bool isChecked) {
    setState(() {
      if (isChecked) {
        selectedItems.add(item);
      } else {
        selectedItems.remove(item);
      }
    });
  }
}

class Half extends StatelessWidget {
  const Half({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('하프 앤 하프 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/half_half_00_1.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/half_half_00_1.jpg', width: 132,),
                Image.asset('assets/nomore/half_half_00_2.jpg', width: 132,),
                Image.asset('assets/nomore/half_half_00_3.jpg', width: 132,),
                Image.asset('assets/nomore/half_half_00_4.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('하프 앤 하프 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('한판에 두가지의 피자를 동시에 즐길 수 있는 피자'),
            SizedBox(height: 10,),
            Text('R 18,800 ~  L 24,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}

class Oksae extends StatelessWidget {
  const Oksae({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('옥수수 새우 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/corn_shrimp_pizza_02.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/corn_shrimp_pizza_01.jpg', width: 132,),
                Image.asset('assets/nomore/corn_shrimp_pizza_05.png', width: 132,),
                Image.asset('assets/nomore/corn_shrimp_pizza_03.jpg', width: 132,),
                Image.asset('assets/nomore/corn_shrimp_pizza_04.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('옥수수 새우 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('매콤한 양념에 숙성된 통새우와 달콤한 하바나 통 옥수수의 토핑으로 구성된\n노모어피자의 인기메뉴',),
            ),
            SizedBox(height: 10,),
            Text('P 12,300~  R 22,800 ~  L 30,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}

class Nyokki extends StatelessWidget {
  const Nyokki({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('바질 마스카포네 뇨끼 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/nyokki01.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/basil_mascarpone_pizza_01.jpg', width: 132,),
                Image.asset('assets/nomore/basil_mascarpone_pizza_02.jpg', width: 132,),
                Image.asset('assets/nomore/basil_mascarpone_pizza_03.jpg', width: 132,),
                Image.asset('assets/nomore/basil_mascarpone_pizza_04.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('바질 마스카포네 뇨끼 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('바질과 썬드라이토마토 그리고 마스카포네치즈의 풍미와\n쫄깃한 뇨끼의 식감을 함께 즐길 수 있는 피자'),
            ),
            SizedBox(height: 10,),
            Text('P 11,800~  R 21,800 ~  L 28,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}

class Doublepp extends StatelessWidget {
  const Doublepp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('더블 페퍼로니 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/더블-페퍼로니-피자.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/double_pepperoni_pizza_02.jpg', width: 132,),
                Image.asset('assets/nomore/double_pepperoni_pizza_03.jpg', width: 132,),
                Image.asset('assets/nomore/double_pepperoni_pizza_04.jpg', width: 132,),
                Image.asset('assets/nomore/pepperoni_pizza_01-1.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('더블 페퍼로니 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('매콤하면서 짭짤한 페퍼로니가 가득 올라간 피자'),
            SizedBox(height: 10,),
            Text('P 11,300~  R 20,800 ~  L 27,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}

class Bacon extends StatelessWidget {
  const Bacon({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('베이컨 포테이토 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/bacon_potato_pizza_01.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/bacon_potato_pizza_02.jpg', width: 132,),
                Image.asset('assets/nomore/bacon_potato_pizza_03.jpg', width: 132,),
                Image.asset('assets/nomore/bacon_potato_pizza_04.jpg', width: 132,),
                Image.asset('assets/nomore/bacon_potato_pizza_05.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('베이컨 포테이토 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('고소한 웨지감자와 짭짤한 베이컨이 잘 어우러진 피자'),
            SizedBox(height: 10,),
            Text('P 11,300~  R 20,800 ~  L 27,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}

class Sweet extends StatelessWidget {
  const Sweet({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('스윗 고구마 피자',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/nomore/스윗-고구마-피자.jpg', width: 600,),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/nomore/sweet_potato_pizza_01.jpg', width: 132,),
                Image.asset('assets/nomore/sweet_potato_pizza_02.jpg', width: 132,),
                Image.asset('assets/nomore/sweet_potato_pizza_03.jpg', width: 132,),
                Image.asset('assets/nomore/sweet_potato_pizza_04.jpg', width: 132,),
              ],
            ),
            SizedBox(height: 20,),
            Text('스윗 고구마 피자',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 25,),),
            SizedBox(height: 20,),
            Text('달콤한 고구마와 각종 재료들을 한 번에 즐길 수 있는 피자'),
            SizedBox(height: 10,),
            Text('P 11,300~  R 20,800 ~  L 27,800 ~',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
          ],
        ),
      ),
    );
  }
}




class Fourth extends StatefulWidget {
  const Fourth({super.key});

  @override
  State<Fourth> createState() => _FourthState();
}
var wo_isChecked = false;
var sh_isChecked = false;
var bo_isChecked = false;
var mc_isChecked = false;
var so_isChecked = false;
var bb_isChecked = false;

class _FourthState extends State<Fourth> {
  @override
  List<String> cartList= [];
  List<String> selectedItems = [];
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('배스킨라빈스',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/woojo');
                  },
                  child: Image.asset('assets/baskin/woojo.png',height: 200,),
                ),
                Text('우주 라이크 봉봉', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: wo_isChecked,
                  onChanged: (value) {
                    setState(() {
                      wo_isChecked = value!;
                      updateSelectedItems('우주 라이크 봉봉', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/shoot');
                  },
                  child: Image.asset('assets/baskin/shoot.png',height: 200,),
                ),
                Text('이상한 나라의 슈팅스타', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: sh_isChecked,
                  onChanged: (value) {
                    setState(() {
                      sh_isChecked = value!;
                      updateSelectedItems('이상한 나라의 슈팅스타', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/bong');
                  },
                  child: Image.asset('assets/baskin/bong.png',height: 200,),
                ),
                Text('피치 요거트', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: bo_isChecked,
                  onChanged: (value) {
                    setState(() {
                      bo_isChecked = value!;
                      updateSelectedItems('피치 요거트', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/macarong');
                  },
                  child: Image.asset('assets/baskin/macarong.png',height: 200,),
                ),
                Text('봉쥬르, 마카롱', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: mc_isChecked,
                  onChanged: (value) {
                    setState(() {
                      mc_isChecked = value!;
                      updateSelectedItems('봉쥬르, 마카롱', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/soop');
                  },
                  child: Image.asset('assets/baskin/soop.png',height: 200,),
                ),
                Text('초코나무 숲', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: so_isChecked,
                  onChanged: (value) {
                    setState(() {
                      so_isChecked = value!;
                      updateSelectedItems('초코나무 숲', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
            Column(
              children: [
                InkWell(
                  onTap: (){
                    Navigator.pushNamed(context, '/bb');
                  },
                  child: Image.asset('assets/baskin/bb.png',height: 200,),
                ),
                Text('블루베리 요거트', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),),
                Checkbox(
                  value: bb_isChecked,
                  onChanged: (value) {
                    setState(() {
                      bb_isChecked = value!;
                      updateSelectedItems('블루베리 요거트', value); // Update selected items list
                    });
                  },
                ),
              ],
            ),
          ],
        ),
    ),
    floatingActionButton: Padding(
    padding: const EdgeInsets.all(8.0),
    child: IconButton(icon: Icon(Icons.add_shopping_cart,size: 50,),onPressed: () {
    // Add selected items to cartList
    cartList.addAll(selectedItems);

    // Show a message or perform other actions
    ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('장바구니에 추가되었습니다!!: $selectedItems', style: TextStyle(fontSize: 16),),),
    );
    },),
    ),
    );
  }

  void updateSelectedItems(String item, bool isChecked) {
    setState(() {
      if (isChecked) {
        selectedItems.add(item);
      } else {
        selectedItems.remove(item);
      }
    });
  }
}

class Woojo extends StatelessWidget {
  const Woojo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('우주 라이크 봉봉',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/woojo.png', width: 400,),
            Text('Would U Like Bon Bon',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('우주 라이크 봉봉',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('인기 플레이버의 역대급 만남!',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/밀크초콜릿.png',width: 100,),
                    Text('밀크초콜릿',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/바닐라.png', width: 100,),
                    Text('바닐라',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/초코아몬드.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('초코아몬드',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/초코프레첼.png', width: 100,),
                    Text('초코프레첼',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Shoot extends StatelessWidget {
  const Shoot({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('이상한 나라의 슈팅스타',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/shoot.png', width: 400,),
            Text('Shooting Star in Wonderland',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('이상한 나라의 슈팅스타',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('딸기와 블루베리가 들어간 솜사탕 아이스크림에\n톡톡 튀는 팝핑캔디로 입안 가득 즐거운 맛',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/블루베리.png',width: 100,),
                    Text('블루베리',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/딸기.png', width: 100,),
                    Text('딸기',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/팝핑캔디.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('팝핑 캔디',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Bong extends StatelessWidget {
  const Bong({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('피치 요거트',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/bong.png', width: 400,),
            Text('Peach Yogurt',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('피치 요거트',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('상큼한 복숭아 요거트, 복숭아 샤베트에 복숭아 과육이 가득!',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/요거트.png',width: 100,),
                    Text('요거트',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/복숭아.png', width: 100,),
                    Text('복숭아',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/복숭아과육.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('복숭아 과육',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Macarong extends StatelessWidget {
  const Macarong({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('봉쥬르, 마카롱',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/macarong.png', width: 400,),
            Text('Bonjour, Macaron',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('봉쥬르, 마카롱',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('부드러운 마스카포네 아이스크림과 마카롱, 초콜릿의 달콤한 만남!',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/마스카포네.png',width: 100,),
                    Text('마스카포네 치즈',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/라즈베리.png', width: 100,),
                    Text('라즈베리 시럽',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/마카롱.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('마카롱',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/하트초콜릿.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('하트 초콜릿',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
class Soop extends StatelessWidget {
  const Soop({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('초코나무 숲',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/soop.png', width: 400,),
            Text('Chocolate Forest',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('초코나무 숲',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('그린티와 초콜렛이 만나 초코볼이 열리는 초코나무가 되었어요',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/그린티.png',width: 100,),
                    Text('그린티',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/초콜릿.png', width: 100,),
                    Text('초콜릿',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/크림샌드.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('크림샌드 쿠키',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/초코프레첼.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('초코 프레첼',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
class Bb extends StatelessWidget {
  const Bb({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('블루베리 요거트',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffF986BD),
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/baskin/bb.png', width: 400,),
            Text('Blueberry Yogurt',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),),
            SizedBox(height: 20,),
            Text('블루베리 요거트',style: TextStyle(fontWeight:FontWeight.bold,fontSize: 32,),),
            SizedBox(height: 20,),
            Text('상큼한 요거트와 블루베리의 만남!',style: TextStyle(fontSize: 20),),
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Image.asset('assets/baskin/요거트.png',width: 100,),
                    Text('요거트',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    Image.asset('assets/baskin/블루베리.png', width: 100,),
                    Text('블루베리',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
                SizedBox(width: 20,),
                Column(
                  children: [
                    SizedBox(height: 20,),
                    Image.asset('assets/baskin/블루베리시럽.png', width: 70,),
                    SizedBox(height: 12,),
                    Text('블루베리 시럽',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}




class Fifth extends StatelessWidget {
  const Fifth({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('60계치킨',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffFE5200),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Container(
              child: Image.asset('assets/60/크랑이.jpg'),
            ),
            Container(
              child: Image.asset('assets/60/푸하핫.jpg'),
            ),
            Container(
              child: Image.asset('assets/60/하하핫.jpg'),
            ),
            Container(
              child: Image.asset('assets/60/크크크.jpg'),
            ),
            Container(
              child: Image.asset('assets/60/호랑이.jpg'),
            ),
            Container(
              child: Image.asset('assets/60/간지.jpg'),
            ),
          ],
        ),
      ),
    );
  }
}

class Sixth extends StatelessWidget {
  const Sixth({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('투썸플레이스',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffD50831),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Container(
              child: Image.asset('assets/twosome/two1.jpg'),
            ),
            Container(
              child: Image.asset('assets/twosome/two2.jpg'),
            ),
            Container(
              child: Image.asset('assets/twosome/two3.jpg'),
            ),
            Container(
              child: Image.asset('assets/twosome/two4.jpg'),
            ),
            Container(
              child: Image.asset('assets/twosome/two5.jpg'),
            ),
            Container(
              child: Image.asset('assets/twosome/two6.jpg'),
            ),
          ],
        ),
      ),
    );
  }
}

class Seventh extends StatelessWidget {
  const Seventh({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('맥도날드',style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xffFFC300),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Container(
              child: Image.asset('assets/mcdonald/상하이.png'),
            ),
            Container(
              child: Image.asset('assets/mcdonald/타바스코.png'),
            ),
            Container(
              child: Image.asset('assets/mcdonald/더블상하이.png'),
            ),
            Container(
              child: Image.asset('assets/mcdonald/더블쿼터파운더.png'),
            ),
            Container(
              child: Image.asset('assets/mcdonald/쿼터파운더.png'),
            ),
            Container(
              child: Image.asset('assets/mcdonald/빅맥.png'),
            ),
          ],
        ),
      ),
    );
  }
}
